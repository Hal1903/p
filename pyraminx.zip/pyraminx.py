import tkinter as tk
import random
from minHeap import MinHeap
from copy import deepcopy
import sys

class Pyraminx:
	def __init__(self):
		self.reset()
		self.g = 0
		self.h = 0
		self.f = self.g+self.h
		parent = None
		children = []

	# This is the data structure for the Pyraminx
	
	def reset(self):
		self.faces = {
			'U': [['G'], ['G', 'G', 'G'], ['G', 'G', 'G', 'G', 'G'], ['G', 'G', 'G', 'G', 'G', 'G', 'G']],
			'R': [['R'], ['R', 'R', 'R'], ['R', 'R', 'R', 'R', 'R'], ['R', 'R', 'R', 'R', 'R', 'R', 'R']],
			'L': [['Y'], ['Y', 'Y', 'Y'], ['Y', 'Y', 'Y', 'Y', 'Y'], ['Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y']],
			'B': [['B'], ['B', 'B', 'B'], ['B', 'B', 'B', 'B', 'B'], ['B', 'B', 'B', 'B', 'B', 'B', 'B']]
		}

	def heuristic(self) -> int:
		letter_set = set()
		
		for face_key in self.faces:
			for row in self.faces[face_key]:
				for letter in row:
					letter_set.add(letter)
					if len(letter_set) == 4: 
						return 4  # Early exit if all diff letters found

		return len(letter_set)  # of distinct letters

	# This function rotates the pyraminx face clockwise
	def rotate_face_clockwise(self, face):
		face[0][0], face[1][2], face[3][6], face[3][0] = face[3][0], face[0][0], face[1][2], face[3][6]
		face[1][0], face[2][4], face[3][4], face[2][0] = face[2][0], face[1][0], face[2][4], face[3][4]
		face[1][1], face[2][2], face[3][2], face[2][1] = face[2][1], face[1][1], face[2][2], face[3][2]

	# This function rotates the edges of the pyraminx
	def rotate_edges(self, move):
		if move == 'U':
			temp = self.faces['R'][0].copy()
			self.faces['R'][0] = self.faces['B'][0]
			self.faces['B'][0] = self.faces['L'][0]
			self.faces['L'][0] = temp

		elif move == 'R':
			temp = [self.faces['U'][i][-1] for i in range(4)]
			temp2 = [self.faces['U'][i][-2] if len(self.faces['U'][i]) > 1 else None for i in range(4)]

			for i in range(4):
				self.faces['U'][i][-1] = self.faces['B'][i][-1]
				self.faces['B'][i][-1] = self.faces['L'][i][-1]
				self.faces['L'][i][-1] = temp[i]

			for i in range(4):
				if len(self.faces['B'][i]) > 1:
					self.faces['U'][i][-2] = self.faces['B'][i][-2]
				if len(self.faces['L'][i]) > 1:
					self.faces['B'][i][-2] = self.faces['L'][i][-2]
				if temp2[i] is not None and len(self.faces['L'][i]) > 1:
					self.faces['L'][i][-2] = temp2[i]

		elif move == 'L':
			temp = [self.faces['U'][i][0] for i in range(4)]
			temp2 = [self.faces['U'][i][1] if len(self.faces['U'][i]) > 1 else None for i in range(4)]

			for i in range(4):
				self.faces['U'][i][0] = self.faces['B'][i][0]
				self.faces['B'][i][0] = self.faces['R'][i][0]
				self.faces['R'][i][0] = temp[i]

			for i in range(4):
				if len(self.faces['B'][i]) > 1:
					self.faces['U'][i][1] = self.faces['B'][i][1]
				if len(self.faces['R'][i]) > 1:
					self.faces['B'][i][1] = self.faces['R'][i][1]
				if temp2[i] is not None and len(self.faces['U'][i]) > 1:
					self.faces['R'][i][1] = temp2[i]

		elif move == 'B':
			temp = self.faces['U'][-1].copy()
			self.faces['U'][-1] = self.faces['R'][-1].copy()
			self.faces['R'][-1] = self.faces['L'][-1].copy()
			self.faces['L'][-1] = temp

	def rotate_layer(self, face, layer, direction):
		layer_indices = {1: 0, 2: 1, 3: 2}
		idx = layer_indices.get(layer)
		if idx is None:
			return  

	
		if direction == '':
			self.faces[face][idx] = self.faces[face][idx][-1:] + self.faces[face][idx][:-1]
		else:
			self.faces[face][idx] = self.faces[face][idx][1:] + self.faces[face][idx][:1]

		adjacent = {
			'U': [('L', idx), ('B', idx), ('R', idx)],
			'R': [('U', idx), ('B', idx), ('L', idx)],
			'L': [('U', idx), ('R', idx), ('B', idx)],
			'B': [('U', idx), ('R', idx), ('L', idx)]
		}

		temp = [self.faces[adj_face][idx][:] for adj_face, _ in adjacent[face]]
		if direction == '':
			for i in range(3):
				self.faces[adjacent[face][i][0]][idx] = temp[i - 1]
		else:
			for i in range(3):
				self.faces[adjacent[face][i][0]][idx] = temp[(i + 1) % 3]

	def apply_move(self, move):
		if move == 'U':
			self.rotate_face_clockwise(self.faces['U'])
			self.rotate_edges('U')
		elif move == 'U\'':
			# Apply U twice
			for _ in range(2):
				self.rotate_face_clockwise(self.faces['U'])
				self.rotate_edges('U')
		elif move == 'R':
			self.rotate_face_clockwise(self.faces['R'])
			self.rotate_edges('R')
		elif move == 'R\'':
			for _ in range(2):
				self.rotate_face_clockwise(self.faces['R'])
				self.rotate_edges('R')
		elif move == 'L':
			self.rotate_face_clockwise(self.faces['L'])
			self.rotate_edges('L')
		elif move == 'L\'':
			for _ in range(2):
				self.rotate_face_clockwise(self.faces['L'])
				self.rotate_edges('L')
		elif move == 'B':
			self.rotate_face_clockwise(self.faces['B'])
			self.rotate_edges('B')
		elif move == 'B\'':
			for _ in range(2):
				self.rotate_face_clockwise(self.faces['B'])
				self.rotate_edges('B')
		else:
			# print('might be returning nothing')
			if len(move) == 2:
				face = move[0]
				try:
					layer = int(move[1])
				except ValueError:
					return  
				direction = ''
			elif len(move) == 3 and move[2] == "'":
				face = move[0]
				try:
					layer = int(move[1])
				except ValueError:
					return 
				direction = "'"
			else:
				return 

			if face in ['U', 'R', 'L', 'B'] and layer in [1, 2, 3]:
				self.rotate_layer(face, layer, direction)
	def __str__(self) -> str:
		return str("("+str(self.g)+", "+str(self.h)+")")
	def __repr__(self) -> str:
		return str("("+str(self.g)+", "+str(self.h)+")")
	


class PyraminxGUI:
	def __init__(self, root):
		self.root = root
		self.pyraminx = Pyraminx()
		self.setup_ui()

	def setup_ui(self):
		# Text widget to display the Pyraminx
		self.display_text = tk.Text(self.root, height=30, width=80, font=("Courier", 14))
		self.display_text.pack()

		# Update the display
		self.update_display()

		# Buttons for standard moves
		moves = ['U', 'U\'', 'R', 'R\'', 'L', 'L\'', 'B', 'B\'']
		move_frame = tk.Frame(self.root)
		move_frame.pack()
		for move in moves:
			button = tk.Button(move_frame, text=move, command=lambda m=move: self.make_move(m))
			button.pack(side=tk.LEFT)

		# Buttons for new layer rotations
		faces = ['U', 'R', 'L', 'B']
		layers = ['1', '2', '3']
		directions = ['', "'"]
		layer_move_frame = tk.Frame(self.root)
		layer_move_frame.pack()
		for face in faces:
			for layer in layers:
				for direction in directions:
					move = f"{face}{layer}{direction}"
					button = tk.Button(layer_move_frame, text=move, command=lambda m=move: self.make_move(m))
					button.pack(side=tk.LEFT)

		# Frame for scramble input and button
		scramble_frame = tk.Frame(self.root)
		scramble_frame.pack()

		# Entry for number of scramble moves
		self.scramble_entry = tk.Entry(scramble_frame, width=5)
		self.scramble_entry.insert(0, "2")  # Default value
		self.scramble_entry.pack(side=tk.LEFT)

		# Button to scramble
		scramble_button = tk.Button(scramble_frame, text='Scramble', command=self.scramble)
		scramble_button.pack(side=tk.LEFT)

		# Button to reset
		reset_button = tk.Button(self.root, text='Reset', command=self.reset)
		reset_button.pack()

		# Button to Astar
		astar_button = tk.Button(self.root, text='Astar', command=self.Astar)
		astar_button.pack()

		# Add a new Text widget to display scramble moves
		self.moves_display = tk.Text(self.root, height=5, width=80, font=("Courier", 12))
		self.moves_display.pack()

	def update_display(self):
		self.display_text.delete(1.0, tk.END)
		self.display_text.insert(tk.END, self.pyraminx_to_string())

	def pyraminx_to_string(self):
		result = ""
		for key in self.pyraminx.faces:
			result += f"{key} face:\n"
			rows = len(self.pyraminx.faces[key])
			max_width = len(self.pyraminx.faces[key][-1]) * 2 - 1  # Calculate the maximum width of the bottom row
			for i in range(rows):
				# Calculate the number of spaces needed to center the row
				num_elements = len(self.pyraminx.faces[key][i])
				num_spaces = (max_width - (num_elements * 2 - 1)) // 2
				# Print spaces
				result += " " * num_spaces
				# Print the row elements
				result += " ".join(self.pyraminx.faces[key][i]) + "\n"
			result += "\n"
		return result

	def make_move(self, move):
		self.pyraminx.apply_move(move)
		self.update_display()
		self.display_move(move)

	def display_move(self, move):
		self.moves_display.insert(tk.END, move + " ")
		self.moves_display.see(tk.END) 
		self.root.update()
		self.root.after(500)

	def scramble(self):
		try:
			num_moves = int(self.scramble_entry.get())
		except ValueError:
			num_moves = 5  # Default value

		self.moves_display.delete(1.0, tk.END)

		# Define all possible moves as seen in the image
		# all_moves = [
		#     'U1', 'U1\'', 'U2', 'U2\'', 'U3', 'U3\'',
		#     'R1', 'R1\'', 'R2', 'R2\'', 'R3', 'R3\'',
		#     'L1', 'L1\'', 'L2', 'L2\'', 'L3', 'L3\'',
		#     'B1', 'B1\'', 'B2', 'B2\'', 'B3', 'B3\'',
		#     'U', 'U\'', 'R', 'R\'', 'L', 'L\'', 'B', 'B\''
		# ]
		all_moves = [
			'U1', 'U2', 'U3',
			'R1', 'R2', 'R3',
			'L1', 'L2', 'L3',
			'B1', 'B2', 'B3',
			'U', 'R', 'L', 'B'
		]

		random_moves = random.choices(all_moves, k=num_moves)
		for move in random_moves:
			self.pyraminx.apply_move(move)
			self.update_display()
			self.display_move(move)
			self.root.update()
			self.root.after(100)  # Add a small delay between moves for visibility

			
	def reset(self):
		self.pyraminx.reset()
		self.update_display()
		self.moves_display.delete(1.0, tk.END)

	# Vansh Patel
	def Astar(self): # scrambled
		print("A star clicked")
		ccw = [
			'U1\'', 'U2\'', 'U3\'',
			'R1\'', 'R2\'', 'R3\'', 
			'L1\'', 'L2\'', 'L3\'', 
			'B1\'', 'B2\'', 'B3\'', 
			'U\'', 'R\'', 'L\'', 'B\''
		]
		path = []
		goal = Pyraminx()
		curr = self.pyraminx
		q = MinHeap(10000000) #Q.PriorityQueue() # open list
		closed_list = []
		q.push(curr)
		children = []
		print("curr is", curr==None)

		while (not q.empty()):
			print("loop")
			if (curr == goal):
				print("reached goal")
				path.append(curr)
				pt = curr.parent
				while (pt != None and pt.parent != None):
					pt = pt.parent
					path.append(pt)
				print(path)
				return path # reached goal
			
			child = q.get()
			closed_list.append(curr) # or child?

			# generate children
			c = [deepcopy(curr) for _ in range(0, len(ccw))]
			for cc in c:
				print(f"c==None is {cc is None}: {cc}")
			count = 0
			for move in ccw:
				#pyraminx.apply_move(move)
				children.append(c[count].apply_move(move))
				print(children[count])
				count += 1 # = [c[i].apply_move(move) for i in range(0, len(ccw))]
			# count = 0
			# # for c in children:
			# # 	print(f"Move: c[{count}]==None is {c[count] is None}")
			# # 	count+=1
			# print("Generated Children:")

	# Add a print statement to inspect each child object
			for child in children:
				if child is None:
					print("child was none")
					continue
				if (child in closed_list):
					continue
				print("child:", child)
				# Heuristics
				child.g = child.g+1
				child.h = child.heuristic() # implement
				child.f = child.g + child.h

				# in open list
				for qnode in q:
					if child == qnode and child.g > qnode.g:
						continue
				
				# add to open list
				children.append(child)
		print("something wrong or path not found")

if __name__ == '__main__':
	root = tk.Tk()
	root.title("Pyraminx Puzzle")
	gui = PyraminxGUI(root)
	root.mainloop()
